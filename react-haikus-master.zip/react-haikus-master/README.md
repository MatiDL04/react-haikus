# Enunciado

Increiblemente el enunciado no esta aqui, para llegar a el, por el momento, tenes que hacer click [aquí](https://auspicious-sunfish-a4d.notion.site/Dise-o-Adaptable-4180714f4fa5417b988ff02a347baa1d)

# Introducción a la aplicación Create React

Este proyecto se inició con [Create React App] (https://github.com/facebook/create-react-app).

## Scripts disponibles

En el directorio del proyecto, puede ejecutar:

### `npm start`

Ejecuta la aplicación en el modo de desarrollo. \
Abra [http: // localhost: 3000] (http: // localhost: 3000) para verlo en el navegador.

La página se recargará si realiza modificaciones. \
También verá errores de pelusa en la consola.

### `npm test`

Inicia el corredor de pruebas en el modo de reloj interactivo. \
Consulte la sección sobre [ejecutar pruebas] (https://facebook.github.io/create-react-app/docs/running-tests) para obtener más información.

### `npm run build`

Construye la aplicación para producción en la carpeta `build`. \
Agrupa correctamente React en el modo de producción y optimiza la compilación para obtener el mejor rendimiento.

La compilación se minimiza y los nombres de archivo incluyen los hash. \
¡Tu aplicación está lista para implementarse!

Consulte la sección sobre [implementación] (https://facebook.github.io/create-react-app/docs/deployment) para obtener más información.
