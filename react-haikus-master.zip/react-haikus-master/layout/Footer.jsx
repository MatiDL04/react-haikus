import React from 'react'

const Footer = () => {
    return (
        <div>
            <Footer></Footer>
        </div>
    )
}

export default Footer
